#pragma once
#include "FileSystemElement.h"

class File : public FileSystemElement {
    std::string name;
    int permissions;
public:
    File(const std::string& name);
    void print(std::ostream& os, int indent = 0) const override;
    void printInfo() const override;
    void ls() const override;
    const std::string& getName() const override;
    const std::string& getType() const override;
    void setPermissions(int permissions) override;
    int getPermissions() const override;
};