#pragma once
#include "FileSystemElement.h"
#include <vector>
#include <memory>

class Dir : public FileSystemElement {
    std::string name;
    int permissions;
    std::vector<std::unique_ptr<FileSystemElement>> elements;
public:
    Dir(const std::string& name);
    void add(std::unique_ptr<FileSystemElement> element);

    void print(std::ostream& os, int indent = 0) const override;
    void printInfo() const override;
    void printElementsInfo() const;
    void ls() const override;

    const std::string& getName() const override;
    const std::string& getType() const override;
    void setPermissions(int permissions) override;
    int getPermissions() const override;

    const std::vector<std::unique_ptr<FileSystemElement>>& getElements() const;
};

std::ostream& operator<<(std::ostream& os, const Dir& dir);