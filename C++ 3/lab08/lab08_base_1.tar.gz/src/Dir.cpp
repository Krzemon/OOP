#include "Dir.h"
#include "File.h"
#include "Link.h"
#include <iostream>

Dir::Dir(const std::string& name)
    : name(name), permissions(0777) {}

void Dir::add(std::unique_ptr<FileSystemElement> element) {
    elements.push_back(std::move(element));
}

void Dir::print(std::ostream& os, int indent) const {
    os << std::string(indent, ' ') << "Dir: " << name << "\n";
    for (const auto& elem : elements) {
        elem->print(os, indent + 2);
    }
}

void Dir::printInfo() const {
    std::cout << "Katalog: " << name << ", prawa dostępu: " << permissions << "\n";
}

void Dir::printElementsInfo() const {
    for (const auto& elem : elements) {
        elem->printInfo();  // teraz prawidłowo
    }
}

void Dir::ls() const {
    std::cout << "Zawartość katalogu '" << name << "':\n";
    for (const auto& elem : elements) {
        std::cout << "- " << elem->getName()
                  << " (" << elem->getType()
                  << "), prawa dostępu: " << elem->getPermissions() << "\n";
    }
}

const std::string& Dir::getName() const { return name; }

const std::string& Dir::getType() const {
    static std::string type = "Dir";
    return type;
}

void Dir::setPermissions(int p) { permissions = p; }

int Dir::getPermissions() const { return permissions; }

const std::vector<std::unique_ptr<FileSystemElement>>& Dir::getElements() const {
    return elements;
}

std::ostream& operator<<(std::ostream& os, const Dir& dir) {
    dir.print(os, 0);
    return os;
}